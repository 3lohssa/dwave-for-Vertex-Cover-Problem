import networkx as nx
import matplotlib.pyplot as plt
from dwave.samplers import SimulatedAnnealingSampler
from pyqubo import Binary

# Read the keller4.mis dataset
# Update if different
path = r'D:\docs\cppTraining\演算法\midtermProject\keller4.mis'
instance = []
with open(path) as f:
    for line in f.readlines():
        parts = line.split()
        if parts[0] == 'e':
            first_node = int(parts[1])
            second_node = int(parts[2])
            instance.append((first_node, second_node))

# Create a graph
G = nx.Graph()
G.add_edges_from(instance)

# Define QUBO parameters
A = 2.0  # Penalty for constraint
B = 1.0  # Weight for minimizing vertices

# Initialize QUBO dictionary
Q = {}

# Add constraint terms for each edge
for u, v in G.edges():
    u, v = min(u, v), max(u, v)  # Ensure consistent ordering
    Q[(u, u)] = Q.get((u, u), 0) - A  # -A for x_u
    Q[(v, v)] = Q.get((v, v), 0) - A  # -A for x_v
    Q[(u, v)] = Q.get((u, v), 0) + A  # +A for x_u*x_v

# Add objective terms for each vertex
for v in G.nodes():
    Q[(v, v)] = Q.get((v, v), 0) + B  # +B for x_v

# Solve using Simulated Annealing
sampler = SimulatedAnnealingSampler()
response = sampler.sample_qubo(Q, num_reads=1000)
best_sample = response.first.sample
best_energy = response.first.energy

# Extract the vertex cover
vertex_cover = [v for v in G.nodes() if best_sample.get(v, 0) == 1]
cover_size = len(vertex_cover)

# Verify if it's a valid vertex cover
is_valid = True
for u, v in G.edges():
    if u not in vertex_cover and v not in vertex_cover:
        is_valid = False
        break

# Print results
print(f"Vertex Cover Size: {cover_size}")
print(f"Valid Vertex Cover: {is_valid}")
print(f"Best Energy: {best_energy}")
print(f"Vertex Cover: {vertex_cover}")

# Visualize the graph
plt.figure(figsize=(10, 8))  # Set figure size
pos = nx.spring_layout(G)  # Layout for node positions

# Draw all nodes, with vertex cover nodes in red and others in blue
node_colors = ['red' if node in vertex_cover else 'blue' for node in G.nodes()]
nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=50)
nx.draw_networkx_edges(G, pos, alpha=0.5)
nx.draw_networkx_labels(G, pos, font_size=8)

# Add title and show plot
plt.title("Vertex Cover for keller4.mis (Red: In Cover, Blue: Not in Cover)")
plt.show()
